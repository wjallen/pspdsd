# To download data from the PDB, use the following curl template:

wget https://files.rcsb.org/download/1HRC.pdb.gz

